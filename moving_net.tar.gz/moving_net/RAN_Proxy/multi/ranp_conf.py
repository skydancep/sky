# NCC+NMC / EPC Address
tenants = { "46099" : "172.17.100.250",
    }

# NCC+NMC / Tunnel interface

# Tunnel interface / IP address

#small cell information

# IMSI / VSC
vsc = { 
        "460990002" : "9000",
        "460990003" : "9001",
      }
