import sctp
import socket
import threading

from scapy.all import *
from libmich.utils.repr import *
from libmich.formats.S1AP import *
import zmq

import nas_decoder

soc = sctp.sctpsocket_tcp(socket.AF_INET)
soc.bind(('172.17.99.254',36422))
#soc.connect(('172.17.100.251',36412)) #combine EPC addr. and port
#soc.bind(('192.168.0.51',36422))
soc.connect(('10.31.0.254',36412)) #combine EPC addr. and port
print "connecting to server"

# recv pkt from proxy
zmq_context = zmq.Context()
zmq_recv = zmq_context.socket(zmq.PULL)
zmq_recv.bind("tcp://127.0.0.1:9001")
print "zmq server up."

# send pkt to proxy
local_set = 0 # check another side is up
while local_set == 0:
    try:
        zmq_context = zmq.Context()
        zmq_send = zmq_context.socket(zmq.PUSH)
        zmq_send.connect("tcp://127.0.0.1:8889")
        local_set = 1
        print "local transport set up completed."
    except:
        continue

# send s1 setup to mme
pkts = rdpcap("./2.pcap")
buf2 = str(pkts[8][3].data)
soc.send(buf2)
print "s1 setup."

def handle_uplink():
    s1ap = S1AP_PDU()
    while True:
        local_pkt = zmq_recv.recv()
        s1ap.parse(local_pkt)
        s1ap_ie = s1ap[0].protocolIEs()
        s1ap_procedure_code = s1ap[0].procedureCode()
        print "S1AP_procedure_code:", s1ap_procedure_code
        if s1ap_procedure_code == 12: #initail_attached
            for i in range(1, s1ap_ie+1):
                if s1ap[i].id() == 26:
                    nas_hex_ori = s1ap[i].value()
                    nas = nas_decoder.deal_nas_hex(nas_hex_ori)
                    #nas = nas_decoder.NAS_PDU()
                    #nas.parse(nas_hex_string)
                    print nas.show_imsi()
        #print local_pkt
        soc.send(local_pkt)

def handle_downlink():
    while True:
        rec_pkt = soc.recv(1024)
        print rec_pkt
        zmq_send.send(rec_pkt)

uplink_handler = threading.Thread(target = handle_uplink)
downlink_handler = threading.Thread(target = handle_downlink)
uplink_handler.start()
downlink_handler.start()
