import sys
import socket
import threading

from scapy.all import *
from libmich.utils.repr import *
from libmich.formats.S1AP import *
import sctp
import zmq
import nas_decoder

#socket info
server_ip     = "172.17.100.254"
stcp_port   = 36412
backlog_conns = 10

#bind socket
try:
    stcp_socket = sctp.sctpsocket_tcp(socket.AF_INET)
    stcp_socket.events.clear()
    stcp_socket.bind((server_ip, stcp_port))
    stcp_socket.listen(backlog_conns)
    print "Virtual MME serving..."
except:
    print "Virtual MME start with error."
    sys.exit(0)

#send pkt to vsc
try:
    zmq_context = zmq.Context()
    zmq_send = zmq_context.socket(zmq.PUSH)
    zmq_send.bind("tcp://127.0.0.1:8888")
    print "local transport sever side up."
except:
    print "local tranpoort sever side error"
    sys.exit(0)

#receive pkt from vsc
local_set = 0 # check another side is up.
while local_set == 0:
    try:
        zmq_context = zmq.Context()
        zmq_receiver = zmq_context.socket(zmq.PULL)
        zmq_receiver.connect("tcp://127.0.0.1:8889")
        local_set = 1
        print "local transport set up completed."
    except:
        continue

def handle_uplink(client_socket):
    downlink_handler = threading.Thread(target = handle_downlink, args = (client, ))
    downlink_handler.start()
    
    while True:
        alert =  "Packet detecting..."
        print alert
        c_packet = client_socket.recv(1024)
        s1ap = S1AP_PDU()
        s1ap.parse(c_packet)
        print s1ap.show()
        s1ap_ie = s1ap[0].protocolIEs()
        s1ap_procedure_code = s1ap[0].procedureCode()
        print "S1AP_procedure_code:", s1ap_procedure_code
        if s1ap_procedure_code == 17: #s1_setup
            pkts = rdpcap("/root/moving_net/pcap/2.pcap")
            buf = str(pkts[10][3].data)
            client_socket.send(buf)
        elif s1ap_procedure_code == 12: #initail_attached
            for i in range(1, s1ap_ie+1):
                if s1ap[i].id() == 26:
                    nas_hex_ori = s1ap[i].value()
                    zmq_send.send(c_packet)
                    nas_hex = nas_hex_ori[1:] #[1:] remove the lead bit
                    nas_hex_string = " ".join("{:02x}".format(ord(c)) for c in nas_hex)
                    #print nas_hex_string
                    nas = nas_decoder.NAS_PDU()
                    nas.parse(nas_hex_string)
                    print nas.show()
        #uplink nas transport, initial context setup, uecapabilityinfoindication
        elif s1ap_procedure_code == 13: 
            zmq_send.send(c_packet)
        elif s1ap_procedure_code == 9:
            zmq_send.send(c_packet)
        elif s1ap_procedure_code == 22: 
            zmq_send.send(c_packet)

def handle_downlink(client_socket):
    while True:
        print "local transport listening..."    
        local_pkt = zmq_receiver.recv()
        client_socket.send(local_pkt)

while True:
    (client, addr) = stcp_socket.accept()
    print "Client connected."
    print "Client Info: {0}:{1}".format(addr[0], addr[1])
    uplink_handler = threading.Thread(target = handle_uplink, args = (client, ))
    uplink_handler.start()
