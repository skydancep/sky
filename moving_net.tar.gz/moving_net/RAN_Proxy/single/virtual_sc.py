import sctp
import socket
import threading

from scapy.all import *
import zmq

soc = sctp.sctpsocket_tcp(socket.AF_INET)
#soc.bind(('127.0.0.1',36422))
#soc.connect(('127.0.0.1',36412)) #combine EPC addr. and port
#soc.bind(('172.17.100.254',36422))
soc.bind(('172.17.100.254',36422))
#soc.connect(('172.17.100.250',36412)) #combine EPC addr. and port
soc.connect(('10.41.0.254', 36412)) #combine EPC addr. and port
print "connecting to server"

# send pkt to proxy
zmq_context = zmq.Context()
zmq_send = zmq_context.socket(zmq.PUSH)
zmq_send.bind("tcp://127.0.0.1:8889")
print "zmq server up."

# recive pkt from proxy
local_set = 0 # check another side is up
while local_set == 0:
    try:
        zmq_context = zmq.Context()
        zmq_receiver = zmq_context.socket(zmq.PULL)
        zmq_receiver.connect("tcp://127.0.0.1:8888")
        local_set = 1
        print "local transport set up completed."
    except:
        continue

# send s1 setup to mme
pkts = rdpcap("/root/moving_net/pcap/2.pcap")
buf2 = str(pkts[8][3].data)
soc.send(buf2)
print "s1 setup."

def handle_uplink():
    while True:
        local_pkt = zmq_receiver.recv()
        print local_pkt
        soc.send(local_pkt)

def handle_downlink():
    while True:
        rec_pkt = soc.recv(1024)
        print rec_pkt
        zmq_send.send(rec_pkt)

if __name__ == '__main__':
    uplink_handler = threading.Thread(target = handle_uplink)
    downlink_handler = threading.Thread(target = handle_downlink)
    uplink_handler.start()
    downlink_handler.start()
