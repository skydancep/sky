import sys
import socket

#socket info
#server_ip = "127.0.0.1"
server_ip = "172.17.100.254"
udp_port = 2152 #GTP-U

small_cell_ip = "172.17.142.121"
epc_ip = "172.17.100.250"
pdn_ip = "140.96.172.133"

#bind socket
try:
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.bind((server_ip, udp_port))
    print "GTP-U server is serving" 
except:
    print "GTP-U server start with error"
    sys.exit(0)

while True:
    data, addr = udp_socket.recvfrom(2048)
    print data, addr[0] 
    #uplink
    if addr[0] == small_cell_ip:
        print "213"
        udp_socket.sendto(data, (epc_ip, udp_port))
        print "222"
    #downlink
    if addr[0] == epc_ip:
        udp_socket.sendto(data, (small_cell_ip, udp_port))
