#! /usr/bin/env python

from tabulate import tabulate

Sec_hdr = {
    0 : 'No security',
    1 : 'Integrity protected',
    2 : 'Integrity protected and ciphered',
    3 : 'Integrity protected with new EPS security context',
    4 : 'Integrity protected and ciphered with new EPS security context', 
    12 : 'Security header for SERVICE REQUEST',
    }

PD = {
    0 : 'group call control',
    1 : 'broadcast call control',
    2 : 'EPS session management messages',
    3 : 'call control; call related SS messages',
    4 : 'GPRS Transparent Transport Protocol (GTTP)',
    5 : 'mobility management messages',
    6 : 'radio resources management messages',
    7 : 'EPS mobility management messages',
    8 : 'GPRS mobility management messages',
    9 : 'SMS messages',
    10 : 'GPRS session management messages',
    11 : 'non call related SS messages',
    12 : 'Location services',
    14 : 'reserved for extension of the PD to one octet length',
    15 : 'used by tests procedures',
    }

EPS_mo_ma = {
    65 : 'EPS mobility management', 
    66 : 'Attachaccept',
    67 : 'Attachcomplete',
    68 : 'Attachreject',
    69 : 'Detachrequest',
    70 : 'Detachaccept',
    72 : 'Tracking area update request',
    73 : 'Tracking area update accept',
    74 : 'Tracking area update complete',
    75 : 'Tracking area update reject',
    76 : 'Extended service request',
    78 : 'Service reject',
    80 : 'GUTI reallocation command',
    81 : 'GUTI reallocatin complete',
    82 : 'Authentication request',
    83 : 'Authentication respone',
    84 : 'Authentication reject',
    92 : 'AUthentication failure',
    85 : 'Identityrequest',
    86 : 'Identity response',
    93 : 'Security mode command',
    94 : 'Security mode complete',
    95 : 'Security mode reject',
    96 : 'EMMstatus',
    97 : 'EMMinformation',
    98 : 'Downlink NAS transport',
    99 : 'Uplink NAS transport',
    100 : 'CS Service notification',
    104 : 'Downlink generic NAS transport',
    105 : 'Uplink generic NAS transport',
    }

class NAS_PDU:

    def __init__(self):
        self.sec_hdr = None
        self.pd = None
        self.eps = None
        self.id_len = None
        self.mcc = None
        self.mnc = None
        self.imsi = None
        self.tmsi = None
        self.mme_group_id = None
        self.mme_code = None

    def imsi_parse(self, imsi_hex):
        self.imsi = imsi_hex[4][0]
        for i in range(5,12):
            self.imsi += imsi_hex[i][1] + imsi_hex[i][0]
        self.mcc = self.imsi[0:3]


    def non_sec_tmsi(self, code):
        self.mcc = code[5][1] + code[5][0] + code[6][1]
        self.mnc = code[7][1] + code[7][0]
        self.mme_group_id = int(code[8]+code[9], 16)
        self.mme_code = int(code[10], 16)
        tmsi_hex = code[11] + code[12] + code[13] + code[14]
        self.tmsi = int(tmsi_hex, 16)
        
        return self.mcc, self.mnc, self.tmsi

    def sec_tmsi(self, code):
        self.eps = EPS_mo_ma.get(int(code[7], 16), 0)
        self.id_len = int(code[9], 16)
        self.mcc = code[11][1] + code[11][0] + code[12][1] 
        self.mnc = code[13][1] + code[13][0]
        self.mme_group_id = int(code[14]+code[15], 16)
        self.mme_code = int(code[16], 16)
        tmsi_hex = code[17] + code[18] + code[19] + code[20]
        self.tmsi = int(tmsi_hex, 16)
        
        return self.mcc, self.mnc, self.tmsi

    def parse(self, nas_hex):
        code = nas_hex.split(' ')
        self.sec_hdr = Sec_hdr.get(int(code[0][0], 16), 0)
        self.pd = PD.get(int(code[0][1], 16), 0)

        if int(code[0][0], 16) == 0:
            self.eps = EPS_mo_ma.get(int(code[1], 16), 0)
            self.id_len = int(code[3], 16)
            
            is_tmsi = 0
            for i in range(0,len(code)+1):
                if i < len(code):
                    if code[i] == "0b" and code[i+1][0] =='f':
                        is_tmsi = 1
            
            if is_tmsi == 0:
                self.imsi_parse(code)
            else:
                self.non_sec_tmsi(code)

        if int(code[0][0], 16) == 1:
            self.sec_tmsi(code)

        return self

    def show(self):
        nas_info = [
                    ["Sec HDR:", self.sec_hdr],
                    ["PD:", self.pd],
                    ["EPS:", self.eps],
                    ["ID length:", self.id_len],
                    ["MCC:", self.mcc],
                    ["MNC:", self.mnc],
                    ["IMSI:", self.imsi],
                    ["T-MSI:", self.tmsi],
                    ["MME Group ID:", self.mme_group_id],
                    ["MME code:", self.mme_code],
                   ]
        return tabulate(nas_info)

if __name__ == "__main__":
    
    sec_0_imsi = '07 41 72 08 49 66 29 14 00 70 84 62 02 e0 60 00 1e 02 03 d0 11 d1 27 17 80 80 21 10 01 00 00 10 81 06 00 00 00 00 83 06 00 00 00 00 00 0d 00 5c 0a 02 90 11 03 4f 18 a4 f1 5d 01 00'
    
    sec_0_tmsi = '07 41 72 0b f6 64 f0 99 80 00 0a b4 d6 2c 39 02 e0 e0 00 20 02 01 d0 11 27 1a 80 80 21 10 01 00 00 10 81 06 00 00 00 00 83 06 00 00 00 00 00 0d 00 00 0a 00 52 64 f0 99 00 01 90 11 03 4f 18 a6 e0'

    sec_1_tmsi = '17 8e da 95 9f 10 07 41 02 0b f6 64 f6 79 52 7b 50 fe 7b 7f f2 04 e0 60 c0 40 00 21 02 03 d0 11 d1 27 1a 80 80 21 10 01 00 00 10 81 06 00 00 00 00 83 06 00 00 00 00 00 0d 00 00 0a 00 19 a4 b5 37 50 0b f6 64 f6 79 80 00 10 e4 c5 de dd 52 64 f6 79 58 20 5c 0a 00 31 03 e5 e0 24 13 64 f6 79 52 7b 11 03 57 58 a6 5d 01 00 e1'
    
    nas = NAS_PDU()
    nas.parse(sec_0_imsi)
    print nas.show()
