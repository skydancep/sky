#!/bin/bash

echo 1 > /proc/sys/net/ipv4/ip_forward

arp -i eth1 -s 172.17.100.254 68:05:CA:37:58:53 pub
route add -host 172.17.142.121 eth1
route del -net 172.17.0.0 netmask 255.255.0.0 eth1
