import sys
import socket
import threading

from scapy.all import *
from libmich.utils.repr import *
from libmich.formats.S1AP import *
import sctp
import zmq
import nas_decoder

#socket info
server_ip = "172.17.100.254"
stcp_port = 36412
backlog_conns = 10

op1_imsi = "244990000002002"
#op2_imsi = "244990000003561"
op2_imsi = "460990000041002"

#bind socket
try:
    stcp_socket = sctp.sctpsocket_tcp(socket.AF_INET)
    stcp_socket.events.clear()
    stcp_socket.bind((server_ip, stcp_port))
    stcp_socket.listen(backlog_conns)
    print "Virtual MME serving..."
except:
    print "Virtual MME start with error."
    sys.exit(0)

#recv pkt from vsc
try:
    zmq_context = zmq.Context()
    zmq_recv = zmq_context.socket(zmq.PULL)
    zmq_recv.bind("tcp://127.0.0.1:8889")
    print "local transport sever side up."
except:
    print "local tranpoort sever side error"
    sys.exit(0)

def conn_to_vsc(port): #send pkt to vsc
    zmq_local_set = 0 # check another side is up.
    while zmq_local_set == 0:
        try:
            zmq_context = zmq.Context()
            zmq_send = zmq_context.socket(zmq.PUSH)
            zmq_send.connect("tcp://127.0.0.1:"+str(port))
            zmq_local_set = 1
            print '#' + str(port) + " transport set up completed."
            return zmq_send
        except:
            continue

op1_send = conn_to_vsc(9000)
op2_send = conn_to_vsc(9001)

def handle_uplink(client_socket):
    downlink_handler = threading.Thread(target = handle_downlink, args = (client, ))
    downlink_handler.start()
    
    alert =  "Packet detecting..."
    print alert

    imsi_dict = {}
    tmsi_dict = {}
    ue_imsi = ""
    ue_tmsi = ""
    s1ap = S1AP_PDU()
    
    while True:
        c_packet = client_socket.recv(1024)
        
        s1ap.parse(c_packet)
        s1ap_ie = s1ap[0].protocolIEs()
        s1ap_procedure_code = s1ap[0].procedureCode()
        
        if s1ap[1][0].show().split(":")[2].split("'")[0][1:] == "id-eNB-UE-S1AP-ID":
            enb_ue_s1ap_id = str(s1ap[1][4].show().split(":")[1].split("'")[0][1:-1])
        else:
            enb_ue_s1ap_id = str(s1ap[2][4].show().split(":")[1].split("'")[0][1:-1])

        #print s1ap.show()
        #print s1ap[1][0].show().split(":")[2].split("'")[0][1:]
        print "S1AP_procedure_code:", s1ap_procedure_code
        
        if s1ap_procedure_code == 17: #s1_setup
            pkts = rdpcap("/root/moving_net/pcap/2.pcap")
            buf = str(pkts[10][3].data)
            client_socket.send(buf)
        elif s1ap_procedure_code == 12: #initail_attached
            for i in range(1, s1ap_ie+1):
                if s1ap[i].id() == 26:
                    nas_hex_ori = s1ap[i].value()
                    nas = nas_decoder.deal_nas_hex(nas_hex_ori)
                    print nas.show()
                    print "enb_id:", enb_ue_s1ap_id
                    ue_imsi = nas.show_imsi()
                    ue_tmsi = nas.show_tmsi()
                    if ue_imsi == op1_imsi:
                        print "attach to OP1"
                        op1_send.send(c_packet)
                        imsi_dict.setdefault(enb_ue_s1ap_id, ue_imsi)
                    elif ue_imsi == op2_imsi:
                        print "attach to OP2"
                        op2_send.send(c_packet)
                        imsi_dict.setdefault(enb_ue_s1ap_id, ue_imsi)
                    else:
                        print "-- unknow device --"
        
        elif s1ap_procedure_code == 13 or s1ap_procedure_code == 9  or  s1ap_procedure_code == 22: 
        #uplink nas transport, initial context setup, uecapabilityinfoindication
            if imsi_dict.get(enb_ue_s1ap_id) == op1_imsi:
                op1_send.send(c_packet)
            elif imsi_dict.get(enb_ue_s1ap_id) == op2_imsi:
                op2_send.send(c_packet)

def handle_downlink(client_socket):
    while True:
        print "local transport listening..."    
        local_pkt = zmq_recv.recv()
        client_socket.send(local_pkt)

while True:
    (client, addr) = stcp_socket.accept()
    print "Client connected."
    print "Client Info: {0}:{1}".format(addr[0], addr[1])
    uplink_handler = threading.Thread(target = handle_uplink, args = (client, ))
    uplink_handler.start()
