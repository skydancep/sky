# This directory receives pickled ASN.1 modules after being compiled
# by compile() function in libmich/asn1/processor